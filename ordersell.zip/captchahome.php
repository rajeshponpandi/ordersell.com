<?php
session_start();
header('Content-Type: image/png');

// Generate CAPTCHA text
$captcha_text = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'), 0, 6);
$_SESSION['captcha_text'] = $captcha_text;

// Create the CAPTCHA image
$width = 120;
$height = 40;
$image = imagecreate($width, $height);
$bg_color = imagecolorallocate($image, 255, 255, 255);
$text_color = imagecolorallocate($image, 0, 0, 0);
$font_size = 5;
$font_x = ($width - imagefontwidth($font_size) * strlen($captcha_text)) / 2;
$font_y = ($height - imagefontheight($font_size)) / 2;
imagestring($image, $font_size, $font_x, $font_y, $captcha_text, $text_color);

// Output the image
imagepng($image);
imagedestroy($image);
?>