<?php
session_start();



// Handle form submission
$message = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    

    // Server-side validation
    if (empty($name) || empty($phone) || empty($email)) {
        $message = 'All fields are required.';
   
    } else {
        $to = 'support@ordersell.com';
        $subject = 'HomePage CallBack form International';
        $message_body = "Name: $name\nPhone: $phone\nEmail: $email";
        $headers = "From: $email";

        if (mail($to, $subject, $message_body, $headers)) {
            $message = 'Your message has been sent successfully.';
        } else {
            $message = 'There was a problem sending your message.';
        }
       
    }
}
?>

<!DOCTYPE html>

<html lang="en">

<head lang="en">

         <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <meta name="keywords" content="domain, hosting, website hosting, domain and hosting, buy domain and hosting, ssl, vps, website design" />

<meta name="description" content="Buy domain & web hosting services from Ordersell.com to get your business online in simple steps. Host your domain on a plan that features 99.9% uptime and 24/7 tech support." />

    <meta name="google-site-verification" content="Y09viozL2gymynlQvRtsaMXmjEqK1tSJOccWMh8HYBY">

    <title>Buy Domains, Hosting, for Websites - OrderSell</title>

    <meta name="robots" content="index,follow">

    <!--Geo Targeting-->

 

    <!--Styles for RTL-->



    <!--<link rel="stylesheet" type="text/css" href="css/rtl.css">-->

 <script>
        (function() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'https://ipapi.co/json/', false); // Synchronous request
            xhr.send(null);

            if (xhr.status === 200) {
                var geoData = JSON.parse(xhr.responseText);
                if (geoData.country_code === 'IN') {
                    window.location.href = 'https://ordersell.com';
                } 
            }
        })();
    </script>
<!--Geo Targeting-->

    <link rel="icon" type="image/x-icon" href="img/favicon.ico">



    <link rel="stylesheet" type="text/css" href="css/fonts.css">

    <link rel="stylesheet" type="text/css" href="css/crumina-fonts.css">

    <link rel="stylesheet" type="text/css" href="css/normalize.css">

    <link rel="stylesheet" type="text/css" href="css/grid.css">

    <link rel="stylesheet" type="text/css" href="css/base.css">

    <link rel="stylesheet" type="text/css" href="css/blocks.css">

    <link rel="stylesheet" type="text/css" href="css/layouts.css">

    <link rel="stylesheet" type="text/css" href="css/modules.css">

    <link rel="stylesheet" type="text/css" href="css/widgets-styles.css">

	<link rel="stylesheet" type="text/css" href="css/style.css">

   





    <!--Plugins styles-->



    <link rel="stylesheet" type="text/css" href="css/jquery.mCustomScrollbar.min.css">

    <link rel="stylesheet" type="text/css" href="css/swiper.min.css">

    <link rel="stylesheet" type="text/css" href="css/primary-menu.css">

   

    <!--External fonts-->



    <link href='https://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>

    <style type="text/css">

<!--

.style1 {color: #FF0000}

.style2 {color: #FF0000}

.style6 {color: #000000}
.style12 {color: #FF6600}
-->

label,a, body 
{
	font-family : Arial, Helvetica, sans-serif;
	font-size : 14px; 
}
.err
{
	font-family : Verdana, Helvetica, sans-serif;
	font-size : 12px;
	color: red;
}
    </style>

  <style>
    /* Keyframes for the blink effect */
    @keyframes blink {
      0% { opacity: 1; }
      50% { opacity: 0; }
      100% { opacity: 1; }
    }

    /* Applying the animation to the link */
    .blinking-link {
      animation: blink 1s infinite; /* Slowed down to 3 seconds */
      color: blue;
      text-decoration: none;
    }	
  </style>

	
<!-- a helper script for vaidating the form-->
<script language="JavaScript" src="scripts/gen_validatorv31.js" type="text/javascript"></script>	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<style>
  /* Add your desired input and button styles here */
  .containernew {
    text-align: center; /* Center align content */
  }

  #domainname {
    width: 80%; /* Width of the input box */
    padding: 10px; /* Padding inside the input box */
    border: 2px solid #333; /* Thick border */
    border-radius: 5px; /* Rounded corners */
    font-size: 18px; /* Font size */
    margin-bottom: 10px; /* Space below input box */
    box-sizing: border-box; /* Ensure padding and border are included in width */
	color: #000;
  }

  #domainname::placeholder {
    color: black; /* Placeholder text color */
  }

  #submit-button {
    background-color: #4CAF50; /* Green background */
    color: white; /* White text */
    padding: 10px 20px; /* Padding */
    border: none; /* Remove border */
    border-radius: 5px; /* Rounded corners */
    cursor: pointer; /* Pointer cursor on hover */
    font-size: 16px; /* Font size */
  }

  /* Add a hover effect */
  #submit-button:hover {
    background-color: #45a049; /* Darker green on hover */
  }

  /* Style for invalid domain */
  .domain_fail {
    border: 3px solid red; /* Red border for invalid domain */
  }
.style21 {color: #FFFF00}
.style9 {color: #FFFFFF}
</style>



<style>
   
        .containermsg {
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: azure;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: flex;
            flex-direction: row;
            align-items: center;
        }

        input[type="text"], input[type="tel"], input[type="email"] {
            padding: 10px;
            margin-right: 10px;
            border: 1px solid #000;
            border-radius: 5px;
            outline: none;
            font-size: 16px;
            color: #000 solid; /* Text color set to black */
			text: #000 solid; 
        }

        input[type="submit"] {
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #218838;
        }

        .message {
            margin-top: 20px;
            font-size: 16px;
            color: #28a745;
        }
    </style>
	  <style>
        .contact-form-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 900px;
            max-width: 1100px;
            padding: 20px;
            margin: 0 auto;
            background: beige;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            flex-direction: column; /* Align items in a column */
        }
        .contact-form {
            display: flex;
            align-items: center;
            width: 100%;
            flex-wrap: wrap; /* Wrap items to next line if needed */
        }
        .contact-form input[type="text"],
        .contact-form input[type="tel"],
        .contact-form input[type="email"],
        .contact-form input[type="submit"],
        .captcha-container input {
            padding: 10px;
            margin: 10px; /* Provide spacing around elements */
            border: 1px solid #000;
            border-radius: 4px;
            flex: 1;
        }
        .captcha-container {
            display: flex;
            align-items: center;
        }
        .captcha-container img {
            margin-right: 10px;
        }
        .message {
            margin-top: 20px; /* Add margin to separate message from form */
            color: red;
        }
		
		input::placeholder {
            color: #000; /* Set placeholder text color to black */
        }
      .style10 {color: #FF0033}
      </style>
     <script>
        function validateForm() {
            var name = document.forms["contactForm"]["name"].value;
            var phone = document.forms["contactForm"]["phone"].value;
            var email = document.forms["contactForm"]["email"].value;
            
            if (name == "" || phone == "" || email == "" || captcha == "") {
                alert("All fields must be filled out");
                return false;
            }
            return true;
        }
    </script>

<style>
    /* WhatsApp Icon Styles */
    #whatsapp-icon {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 1000;
      width: 60px;
      height: 60px;
      background-color: #25d366;
      border-radius: 50%;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      transition: transform 0.3s ease-in-out;
    }

    #whatsapp-icon:hover {
      transform: scale(1.1);
    }

    #whatsapp-icon img {
      width: 40px;
      height: 40px;
      object-fit: cover;
    }
  </style>
  <style>
    /* Keyframes for the blink effect */
    @keyframes blink {
      0% { opacity: 1; }
      50% { opacity: 0; }
      100% { opacity: 1; }
    }

    /* Applying the animation to the link */
    .blinking-link {
      animation: blink 1s infinite; /* Slowed down to 3 seconds */
      color: blue;
      text-decoration: none;
    }	
  </style>  

</head>





<body class=" ">

<!-- Header -->
<div class="top-bar top-bar-dark">
    <div class="container">
            <div class="top-bar-contact">
                <div class="contact-item style9 no-menu-box">
                <a href="https://ordersell.com"><strong>Home</strong></a>                </div>

                <div class="contact-item">
                    91 7900 916 000
                </div>

                <div class="contact-item">
                    <a href="mailto:info@ordersell.com">info@ordersell.com</a>
                </div>

                <div class="contact-item">
                    <span>Mon. - Sun.</span> 09:00 - 21:00 IST
                </div>
            </div>

            <div class="login-block">
                <img src="img/signin_dark.png" class="sign-in">
                <a href="https://ordersell.com/account/index.php?fuse=home&view=login">My Account</a> 
            </div>

           
            </div>

         


    </div>
</div>



<!-- Header -->





<header class="header" id="site-header">



    <div class="container">



        <div class="header-content-wrapper">



            <div class="logo">

                <a href="https://ordersell.com/int" class="full-block-link"></a>

                <img src="img/logo.png" alt="Seosight">

                <div class="logo-text">                </div>
            </div>



            <nav id="primary-menu" class="primary-menu">



                <a href='javascript:void(0)' id="menu-icon-trigger" class="menu-icon-trigger showhide">

                    <span class="mob-menu--title">Menu</span>

                        <span id="menu-icon-wrapper" class="menu-icon-wrapper" style="visibility: hidden">

                            <svg width="1000px" height="1000px">

                                <path id="pathD" d="M 300 400 L 700 400 C 900 400 900 750 600 850 A 400 400 0 0 1 200 200 L 800 800"></path>

                                <path id="pathE" d="M 300 500 L 700 500"></path>

                                <path id="pathF" d="M 700 600 L 300 600 C 100 600 100 200 400 150 A 400 380 0 1 1 200 800 L 800 200"></path>
                            </svg>
                        </span>                </a>



                <!-- menu-icon-wrapper -->



                 <ul class="primary-menu-menu">

                      


 <li>
            <a href="https://ordersell.com"><strong>Home</strong></a>        </li>
                      <li>
            <a href="domain-registration">
                <span class="style1"></span>Domain          </a>
            <ul class="dropdown">
                
                <li>
                    <a href="https://ordersell.com/account/order.php?step=1&productGroup=2&currency=USD" target="_blank">Domain Register & Transfer <i class="seoicon-right-arrow"></i></a>                </li>
            </ul>
        </li>
			 <li>  <a href="web-hosting">Web Hosting</a>        </li>
        <li>
            <a href="vps-server-int">Servers</a>        </li>
         
		
		  
		
        <li>
            <a href="help">Help</a>        </li>

<li>
            <a href="contacts">Contact Us</a>        </li>
        </li>
    </ul>
</nav>



            <ul class="nav-add">
            </ul>
      </div>



    </div>



</header>





<div class="header-spacer"></div>



<!-- ... End Header -->



<!-- Right-menu -->







<!-- ... End Right-menu -->



<div class="content-wrapper">



<!-- Stunning header -->





      <marquee class="sampleMarquee" direction="left" scrollamount="15" behavior="scroll">  <span class="style21">Get</span> Web Hosting with Domain for Just 18$  |   <span class="style21">Affordable</span> VPS Server

      </marquee>



<!-- End Stunning header -->



<!-- Overlay search -->



 



<!-- End Overlay search -->



<!-- Books products grid -->









   

<div class="container-full-width">

            

           <div class="pricing-tables medium-padding120 bg-border-color">

            <div class="container">



                <div class="row">

				

				



<h2 align="center" class="ui-heading" style="margin: 0px; padding: 0px 0px 15px; font-style: normal; font-variant: normal; font-weight: bold; font-size: 62px; line-height: normal; font-family: Rokkitt, serif; color: #000000; text-shadow: rgb(236, 236, 236) 1px 1px 1px;">Domain Registration</h2>

 <p align="center" class="domain-price text-center"><span><span><span class="style5"><small>.<span class="style1"><strong>COM</strong></span></small></span> <span class="style6"> $12 ,</span></span> <span><span class="style1"><small><strong>    .US</strong></small></span> <span class="style6">$10,</span></span> <span><span class="style1"><small><strong>   .IN</strong></small></span> <span class="style6">$10,</span></span> <span><span class="style1"><small><strong>   .UK</strong></small></span> <span class="style6">$10</span></span></p>



 <div class="containernew">
  <input id="domainname" type="text" name="domainname" value='' placeholder='Enter domain name...' />
  <br>
  <button id="submit-button">Search Domain</button>
</div>

<script type="text/javascript">
  var ceURL = 'https://ordersell.com/account/';
  var groupId = 2;
  var currencyCode = 'USD'; // Define the currency code
  var defaultCurrencyCode = 'USD'; // Define the currency code

  // Function to handle placeholder text behavior
  function handlePlaceholder() {
    var input = $('#domainname');
    var placeholderText = 'Enter domain name...';

    // Show placeholder text on hover
    input.attr('placeholder', placeholderText);

    // Remove placeholder text when input is focused
    input.on('focus', function() {
      input.attr('placeholder', '');
    });

    // Restore placeholder text if input is blurred and empty
    input.on('blur', function() {
      if (input.val().trim() === '') {
        input.attr('placeholder', placeholderText);
      }
    });
  }

  // Call handlePlaceholder function on document ready
  $(document).ready(function() {
    handlePlaceholder();
  });

  function checkDomain() {
    var fullname = $('#domainname').val().trim();

    // Basic validation for domain name
    if (!fullname) {
      $('#domainname').addClass('domain_fail');
      $('#domainname').val('Please enter a domain name');
      return;
    } else {
      $('#domainname').removeClass('domain_fail');
    }

    // Check if the input ends with a domain extension
    if (!fullname.includes('.')) {
      fullname += '.com'; // Automatically add .com if not included
    }

    // Extract name and tld from input
    var name = fullname.split('.')[0];
    var tld = fullname.split('.')[1];

    // Disable button to prevent multiple submissions
    $('#submit-button').prop('disabled', true);
    // Change button text to "Searching Domain Please wait..."
    $('#submit-button').text('Searching Domain Please wait...');

    // AJAX POST request to check domain availability
    $.post(ceURL + 'index.php?fuse=clients&action=checkdomain', {
      name: name,
      tld: tld,
      group: groupId,
      currency: currencyCode // Include the currency code in the request
    }, function(response) {
      console.log(response);

      // Handle response
      if (response.error) {
        alert(response.message);
      } else {
        var domainStatus = response.search_results.status;

        if (domainStatus == '0' || domainStatus == '1') {
          window.location = ceURL + 'order.php?step=1&currency=USD&productGroup=' + groupId + '&domainName=' + name + '&tld=' + tld;
        } else {
          alert('Domain not available');
        }
      }
    }, 'json').always(function() {
      // Re-enable button after request completes
      $('#submit-button').prop('disabled', false);
      // Restore original button text
      $('#submit-button').text('Search Domain');
    });
  }

  // Event listener for button click
  $('#submit-button').click(function(e) {
    e.preventDefault();
    checkDomain();
    return false;
  });

  // Event listener for Enter key press
  $('#domainname').keypress(function(e) {
    if (e.which == 13) { // Enter key pressed
      e.preventDefault();
      checkDomain();
    }
  });
</script>


<br><br><p align="center"><strong><span class="style12">Don't Know How to create new  Website?</span> </strong><span class="blinking-link style12 style22"><span class="blinking-link style12 style24"><span class="blinking-link style9 style10"><span class="blinking-link style9 style22"><span class="blinking-link style9 style10"><span class="blinking-link style2 style9"><a href="https://wa.me/917900916000" class="blinking-link">Click Here</a></span></span></span></span></span></span><strong> <span class="style12">For Help</span> </strong></p>

<table width="1200" border="0">
  <tr>
    <td><table width="200" border="0">
  <tr>
    <td><a href="website-maintenance" class="style10"><img src="img/product4.jpg" alt="image" border="0"></a></td>
  </tr>
  <tr>
    <td><a href="website-development" class="style10"><img src="img/product1.jpg" alt="image" border="0"></a></td>
  </tr>
</table>
</td>
    <td><table width="200" border="0">
  <tr>
    <td><a href="reseller-hosting" class="style10"><img src="img/product8.jpg" alt="image" border="0"></a></td>
  </tr>
  <tr>
    <td><a href="vps-server" class="style10"><img src="img/product3.jpg" alt="image" border="0"></a></td>
  </tr>
</table>
</td>
    <td><img src="img/welcome.JPG" width="400" height="220"></td>
  </tr>
</table>


</div>
</div>    </div>    </div>

<!-- ... End Main Slider -->







<!-- SEO-Score -->


<div class="container-fluid">

    <div class="row">



        <div class="seo-score scrollme">



            <div class="container">

                <div class="row">

                    <div class="col-lg-7 col-lg-offset-2 col-md-8 col-md-offset-2 col-xs-12 col-sm-12">

                        <div class="seo-score-content align-center">



                            <div class="heading align-center">

                                <h4 class="h1 heading-title">Talk to Us</h4>

                                <p class="heading-text">Ask Question on WhatsApp </p>

                            </div>



                          <div class="seo-score-form"><p class="sub-title"><a aria-label="Ask on WhatsApp" href="https://wa.me/917900916000"> <img alt="Ask on WhatsApp" src="https://ordersell.com/img/whatsappchat.png" />
<a /></p></div>



                        </div>

                    </div>

                </div>

            </div>



          

        </div>

    </div>

</div>




<!-- ... End SEO-Score -->



<!-- Pricing table -->



<div class="container-fluid">

    <div class="row">

        <div class="pricing-tables medium-padding120 bg-border-color">

            <div class="container">

                <div class="row">

                    <div class="col-lg-7 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-12 col-xs-12">

                        <div class="heading align-center">

                            <h4 class="h1 heading-title">Our Hosting Packages</h4>

                            <div class="heading-line">

                                <span class="short-line"></span>

                                <span class="long-line"></span>

                            </div>

                            <p class="heading-text">Below are the Hosting Service packages.

                            </p>

                        </div>

                    </div>

                </div>



                <div class="row">

                    <div class="pricing-tables-wrap">

                         <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 no-padding">



                            <div class="pricing-tables-item">



                                <div class="pricing-head bg-primary-color"></div>



                                <div class="pricing-content-wrap">



                                    <div class="pricing-tables-icon">

                                      <img src="img/silver.png" alt="personal" width="90" height="84">                                </div>

                                <a href="#" class="pricing-title">Silver </a>

                                <ul class="pricing-tables-position">

                                    

									 <li class="position-item">

                                        <span class="count">1</span>

                                        Website

                                    </li>

                                    <li class="position-item"><span class="count"> 25 GB</span>

                                        Space

                                    </li>

                                    <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Emails

                                    ID</li>

									

									 <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        FTP Accounts

									 <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Database

                                   

                                   

                                    </li>

									</li>

									  

                                </ul>

                              

								<h4 class="rate">15$ /Yr </h4>

                                <a href="https://ordersell.com/account/order.php?step=2&product=562&paymentTerm=12&paymentterm=12&currency=USD" class="btn btn-medium btn--dark">

                                    <span class="text">Buy Now!</span>

                                        <span class="semicircle"></span>

                                  </a>



                                </div>



                            </div>



                        </div>



                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 no-padding">

                            <div class="pricing-tables-item">



                                <div class="pricing-head bg-secondary-color"></div>



                              <div class="pricing-content-wrap">



                                    <div class="pricing-tables-icon">

                                       <img src="img/gold.png" alt="personal">

                                </div>

                                <a href="#" class="pricing-title">Gold</a>

                                  <ul class="pricing-tables-position">

                                    

									<li class="position-item">

                                        <span class="count">3</span>

                                        Website

                                    </li>

                                    <li class="position-item">

                                        <span class="count">100 GB</span>

                                        Space

                                    </li>

                                    <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Emails

                                    </li>

									<li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Database

                                   

                                    <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Bandwidth

                                    </li>

									

                                </ul>

                               

								<h4 class="rate">18 $ / Yr </h4>

                                <a href="https://ordersell.com/account/order.php?step=2&product=561&paymentTerm=12&paymentterm=12&currency=USD" class="btn btn-medium btn--dark">

                                    <span class="text">Buy Now!</span>

                                        <span class="semicircle"></span>

                                  </a>



                                </div>

                            </div>

                        </div>



                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 no-padding">



                            <div class="pricing-tables-item">



                                <div class="pricing-head bg-orange-color"></div>



                                <div class="pricing-content-wrap">



                                    <div class="pricing-tables-icon">

                                      <img src="img/diamond.png" alt="personal">

                                </div>

                                <a href="#" class="pricing-title">Diamond</a>

                                  <ul class="pricing-tables-position">

                                  

									 <li class="position-item">

                                        <span class="count">10</span>

                                        Website Hosting                                    </li>

                                     <li class="position-item">

                                        <span class="count">100 GB</span>

                                        Space                                    </li>

                                     <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Emails                                    </li>

									<li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Database
                                    <li class="position-item"> <span class="count">1 <span class="style2">Free</span> Domain (.com, .in) </span> </li>

									</li>
                                </ul>

                                

								<h4 class="rate">30 $ / Yr </h4>

                                <a href="https://ordersell.com/account/order.php?step=2&product=559&paymentTerm=12&paymentterm=12&currency=USD" class="btn btn-medium btn--dark">

                                    <span class="text">Buy Now!</span>

                                        <span class="semicircle"></span>

                                  </a>



                                </div>

                            </div>

                        </div> </div>

                </div>

            </div>

        </div>

    </div>

</div>



<!-- End Pricing table -->

<!-- Our-video -->







<!-- ... End Offers -->





<!-- Background-mountains -->



<div class="container-fluid">

    <div class="row">

        <div class="background-mountains medium-padding120 scrollme">



          



            <div class="container">

                <div class="row">

                    <div class="col-lg-7 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-12 col-xs-12">

                        <div class="heading align-center">

                            <h4 class="h1 heading-title">Complete Website Solution</h4>

                            <div class="heading-line">

                                <span class="short-line"></span>

                                <span class="long-line"></span>

                            </div>

                            <p class="heading-text">We help you make complete site and below are the combo service in this package.

                            </p>

                        </div>

                    </div>

                </div>

                <div class="row">

                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">

                        <div class="info-box--standard-centered">

                            <div class="info-box-image">

                                <img src="img/domain-registration-icon.jpg" alt="image">

                            </div>

                            <div class="info-box-content">

                                <h4 class="info-box-title">Domain Name </h4>

                                <p class="text">Domain name registration.

                                </p>

                            </div>

                        </div>

                    </div>



                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">

                        <div class="info-box--standard-centered">

                            <div class="info-box-image">

                                <img src="img/web-hosting-icon.png" alt="image">

                            </div>

                            <div class="info-box-content">

                                <h4 class="info-box-title">Hosting Service</h4>

                                <p class="text">We buy Hosting Space for your site.

                                </p>

                            </div>

                        </div>

                    </div>



                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">

                        <div class="info-box--standard-centered">

                            <div class="info-box-image">

                                <img src="img/website-template-icons.jpg" alt="image">

                            </div>

                            <div class="info-box-content">

                                <h4 class="info-box-title">Website Template</h4>

                                <p class="text">Readymade Template for your site.

                                </p>

                            </div>

                        </div>

                    </div>



                    <div class="col-lg-3 col-md-3 col-sm-12 col-xs-12">

                        <div class="info-box--standard-centered">

                            <div class="info-box-image">

                                <img src="img/website-maintenance-icons.jpg" alt="image">

                            </div>

                            <div class="info-box-content">

                                <h4 class="info-box-title">Modification</h4>

                                <p class="text">Basic modification for your site.

                                </p>

                            </div>

                        </div>

                    </div>

                </div>



                <div class="row align-center">

                    <div class="btn-block">

                     

                        </a>

                        <a href="website-solution" class="btn btn-medium btn--breez">

                            <span class="text">Read More!</span>

                            <span class="semicircle"></span>

                        </a>

                    </div>

                </div>



            </div>





        </div>

    </div>

</div>



<!-- End Background-mountains -->





<!-- Counters -->



<div class="container-fluid">

    <div class="row bg-green-color">

        <div class="container">

            <div class="row">

              <div class="counters"></div>

            </div>

        </div>

    </div>

</div>



<!-- End Counters -->





<!-- Recent-case -->



<div class="container">

    <div class="row medium-padding120">

        <div class="recent-case align-center">



            <div class="col-lg-12">



                <div class="row">

                    <div class="col-lg-7 col-lg-offset-2 col-md-8 col-md-offset-2 col-sm-12 col-xs-12">

                        <div class="heading align-center">

                            <h4 class="h1 heading-title">Most Popular Website Designs</h4>

                            <div class="heading-line">

                                <span class="short-line"></span>

                                <span class="long-line"></span>

                            </div>

                            <p class="heading-text">Below are some website designs.

                            </p>

                        </div>

                    </div>

                </div>



                <div class="row">

                    <div class="case-item-wrap">

                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">

                            <div class="case-item">

                                <div class="case-item__thumb"><img src="img/fashion.jpg" alt="our case"></div>

                                <h6 class="case-item__title"><a href="website-development">Fashion Website</a></h6>

                            </div>

                        </div>



                        <div class="col-lg-4  col-md-4 col-sm-6 col-xs-12">

                            <div class="case-item">

                                <div class="case-item__thumb">

                                    <img src="img/medinova.jpg" alt="our case">

                                </div>

                                <h6 class="case-item__title"><a href="website-development">Healthcare Website</a></h6>

                            </div>

                        </div>



                        <div class="col-lg-4  col-md-4 col-sm-6 col-xs-12">

                            <div class="case-item">

                                <div class="case-item__thumb mouseover poster-3d lightbox shadow animation-disabled" data-offset="5">

                                    <img src="img/eflyer.jpg" alt="our case">

                                </div>

                                <h6 class="case-item__title"><a href="website-development">Shopping</a></h6>

                            </div>

                        </div>

                    </div>

                </div>



                <a href="website-development" class="btn btn-medium btn--dark">

                    <span class="text">All Projects</span>

                    <span class="semicircle"></span>

                </a>

            </div>



        </div>

    </div>

</div>



<!-- End Recent-case -->





<!-- Testimonial-slider -->



<div class="container-fluid">

    <div class="row">

        <div class="testimonial-slider scrollme">

            <div class="container">

                <div class="row">

                    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">

                        <div class="heading">

                            <h4 class="h1 heading-title">Happy Clients

                                About Us</h4>

                            <div class="heading-line">

                                <span class="short-line bg-yellow-color"></span>

                                <span class="long-line bg-yellow-color"></span>

                            </div>

                            <p class="heading-text c-white">Voice of our Clients.

                            </p>

                        </div>

                        <div class="signature js-animate-icon">

                            <svg xmlns="http://www.w3.org/2000/svg" width="200" height="60">

                                <path fill="none" stroke="#2f2c2c" stroke-width="1.4"

                                      d="M24.78 42.5C11.28 41.06.96 36 1.16 26.86 1.62 11.6 16.76 3.6 28.13 3.25c5.44-.16 9.8 2.38 10.2 5.8.86 7.66-19.23 15.62-19.23 15.62s17.86-6.57 24.66 2.2c2.8 3.6-11.8 10.65-11.8 10.65s-8.8 3.35-7.65-.24c1.78-5.52 16.8-10.1 18.42-10.3 3.17-.4 7.1-.4 8 .12 1.33.78-1.7 4.14-.94 4.86.76.72 3.82-2.55 3.94-1.97.12.57-.64 2.63.58 3 1.2.38 2.3-1.1 4.28-1.5 1.97-.4 1.83-.44 3.6-.12 1.76.32 2.1.64 3.47 1.4 1.36.74.86 2.22 1.96 1.6 1.1-.6 1.43-4.16 2.44-4.04 1.02.1.03 5.38 1.63 4.5 1.6-.85 4.74-7.97 4.74-7.97s-.82 4.04 0 3.93c3.14-.4 8.12-2.57 14.48-3.36 6.37-.78 8.67-.35 11 .24 1.92.48 2.67 2.3 2.67 2.3"

                                      stroke-linecap="round" stroke-linejoin="round"></path>

                                <path fill="none" stroke="#2f2c2c" stroke-width="1.4"

                                      d="M113.7 15.75s-1.1-2.78-3.6-2.08c-5.83 1.62-16.2 7.68-16.44 15.63-.46 16.3 21.1 11.14 22.7 11 13.6-1.2 17.38-9.96 17.36-14.48-.06-14.3-19.07-10.3-21.07-10.07-7.9.92-10.48 1.57-10.48 1.57"></path>

                                <path fill="none" stroke="#2f2c2c" stroke-width="1.4" d="M119.7 1.05c-2.53 13.9-5.1 27.83-2.53 41.44" stroke-linecap="round"></path>

                                <path fill="none" stroke="#2f2c2c" stroke-width="1.4" d="M133.6 27.8c-6.62-.42-12.6.37-17.36 3.35"></path>

                                <path fill="none" stroke="#2f2c2c" stroke-width="1.4"

                                      d="M131.52 32.77s3.95-.13 8.34-.93c2.4-.43 5-1.73 7.87-1.85 2.87-.12 1.74 1.44 3.6 1.38 4.62-.14 7.98-.3 14.92-.7 6.95-.4 9.76-2.76 12.86-.92 1.7 1 1.4 3.13 1.4 3.13"

                                      stroke-linecap="round"></path>

                                <path fill="none" stroke="#2f2c2c" stroke-width="1.4" d="M153.52 31.03s2.27-2.74-.7-3.35c-3.36-.7-3.7 2.43-3.7 2.43"></path>

                            </svg>

                        </div>

                    </div>



                    <div class="col-lg-7 col-lg-offset-1 col-md-8 col-sm-12 col-xs-12">



                        <div class="testimonial-item">

                            <!-- Slider main container -->

                            <div class="swiper-container testimonial__thumb overflow-visible" data-effect="fade" data-loop="false">



                                <div class="swiper-wrapper">

                                    <div class="testimonial-slider-item swiper-slide">

                                        <div class="testimonial-content">

                                            <p class="text" data-swiper-parallax="-200">We directly contacted OrderSell and they helped to build our Website at affordable rate.

                                            </p>

                                            <a href="#" class="author" data-swiper-parallax="-150">Jai Kumar</a>

                                            <a href="#" class="company" data-swiper-parallax="-150">Shiv Corporporation</a>



                                        </div>

                                        <div class="avatar" data-swiper-parallax="-50">

                                            <img src="img/avatar.png" alt="avatar">

                                        </div>

                                    </div>

                                    <div class="testimonial-slider-item swiper-slide">

                                        <div class="testimonial-content">

                                            <p class="text" data-swiper-parallax="-200">We visited OrderSell and purchased Domain, Hosting and Installed Template which completed my Site.

                                            </p>

                                            <a href="#" class="author" data-swiper-parallax="-150">Raj Mithal</a>

                                            <a href="#" class="company" data-swiper-parallax="-150">Mithal Corp</a>



                                        </div>

                                        <div class="avatar" data-swiper-parallax="-50">

                                            <img src="img/avatar.png" alt="avatar">

                                        </div>

                                    </div>

                                    <div class="testimonial-slider-item swiper-slide">

                                        <div class="testimonial-content">

                                            <p class="text" data-swiper-parallax="-200">OrderSell engineers manage our website with Website Maintenance Service.

                                            </p>

                                            <a href="#" class="author" data-swiper-parallax="-150">Heman Singh</a>

                                            <a href="#" class="company" data-swiper-parallax="-150">Hemant Realestate</a>



                                        </div>

                                        <div class="avatar" data-swiper-parallax="-50">

                                            <img src="img/avatar.png" alt="avatar">

                                        </div>

                                    </div>

                                </div>

                                <!-- If we need pagination -->

                                <div class="swiper-pagination"></div>



                                <div class="quote">

                                    <i class="seoicon-quotes"></i>

                                </div>

                            </div>



                            

                        </div>

                    </div>

                </div>

            </div>

            

        </div>

    </div>

</div>



<!-- End Testimonial-slider -->





<!-- Offers -->



<div class="container">

    <div class="row medium-padding120">

        <div class="col-lg-12">

            <div class="offers">

                <div class="row">

                    <div class="col-lg-8 col-md-12 col-sm-12 col-xs-12">

                        <div class="heading">

                            <h4 class="h1 heading-title">We Offer a Full Range of Domain & Hosting Services!</h4>

                            <div class="heading-line">

                                <span class="short-line"></span>

                                <span class="long-line"></span>

                            </div>

                        </div>

                    </div>

                </div>



                <div class="row">

                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">

                        <div class="heading">

                            <p class="heading-text">OrderSell.com help you to start your own  Website.                            </p>

                        </div>



                        <ul class="list list--secondary">

                            <li>

                                <i class="seoicon-check"></i>

                                <a href="#">Domain at Best price</a>

                            </li>

                            <li>

                                <i class="seoicon-check"></i>

                                <a href="#">Hosting at Best price</a>

                            </li>

                            <li>

                                <i class="seoicon-check"></i>

                                <a href="#">VPS at Best Price</a>

                            </li>

                            <li>

                                <i class="seoicon-check"></i>

                                <a href="#">SSL Certificate.</a>

                            </li>

							<li>

                                <i class="seoicon-check"></i>

                                <a href="#">Servers.</a>

                            </li>

                        </ul>



                        <a href="#" class="btn btn-medium btn-border c-primary">

                            <span class="text">Read More</span>

                            <span class="semicircle"></span>

                        </a>



                        <a href="#" class="btn btn-medium btn--primary btn-hover-shadow">

                            <span class="text">Contact Us</span>

                            <span class="semicircle"></span>

                        </a>



                    </div>



                    <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">

                        <div class="offers-thumb"><img src="img/offers1.jpg" alt="offers"></div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>



<!-- ... End Offers -->











<!-- Clients -->







<!-- End Clients -->





<!-- Subscribe Form -->







<!-- End Subscribe Form -->

</div> 

</div>







 <!--Start of Tawk.to Script-->
<script type="text/javascript">
var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
(function(){
var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
s1.async=true;
s1.src='https://embed.tawk.to/647ad1cf7957702c744b8326/1h1vs758m';
s1.charset='UTF-8';
s1.setAttribute('crossorigin','*');
s0.parentNode.insertBefore(s1,s0);
})();
</script>
<!--End of Tawk.to Script-->
<!-- Footer -->



<footer class="footer js-fixed-footer" id="site-footer">

    <div class="container">

        <div class="row">



            <div class="info">

                <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">

                    <div class="heading">

                        <h3 class="heading-title">OrderSell!</h3>

                        <div class="heading-line">

                            <span class="short-line"></span>

                            <span class="long-line"></span>

                        </div>

                        <p class="heading-text">All Products and Services Offered by OrderSell.com</p>
                        Office :- 508 Room, Chandra Darshan Sthal, <br>
                          Plot 35, Sector 5, Karanjade, Panvel, <br>
                        Navi Mumbai, Maharashtra, India
						 <br> <br>
					Phone : 91 7900 916 000 <br> 
					Email : info@ordersell.com
                        
                    </div>



                    <div class="socials">

                        <a href="https://facebook.com/#" target="_blank" class="social__item">

                            <img src="svg/facebook.png" alt="facebook">                        </a>

                        <a href="https://twitter.com/#" target="_blank" class="social__item">

                            <img src="svg/twitter.png" alt="twitter">                        </a>

                        <a href="https://instagram.com/#" target="_blank" class="social__item">

                            <img src="svg/instagram.png" alt="Instagram">                        </a>

                        <a href="https://youtube.com/#" target="_blank" class="social__item">

                            <img src="svg/youtube.png" alt="youtube">                        </a>                   </div>

                </div>



                <div class="col-lg-4 col-lg-offset-1 col-md-4 col-md-offset-1 col-sm-12 col-xs-12">

                    <div class="services">

                        <div class="heading">

                            <h3 class="heading-title">Services Provided</h3>

                            <div class="heading-line">

                                <span class="short-line"></span>

                                <span class="long-line"></span>

                            </div>

                        </div>



                        <ul class="list list--primary">

                                                       

			 <li>  <i class="fa fa-caret-right" aria-hidden="true"></i>

                                <a href="web-hosting-int">Web Hosting</a>

                            </li>
							
							<li>

                                <i class="fa fa-caret-right" aria-hidden="true"></i>

                                <a href="vps-server-int">VPS Server</a>

                            </li>
							
							 

                            <li>

                                <i class="fa fa-caret-right" aria-hidden="true"></i>

                                <a href="recruitment-service">Recruitment Services</a>

                            </li>

                            
 

                             

                            <li>

                                <i class="fa fa-caret-right" aria-hidden="true"></i>

                                <a href="domain-registration-int">Domain Registration</a>

                            </li>

                           

                        </ul>



                        <ul class="list list--primary">

                            <li>

                                <i class="fa fa-caret-right" aria-hidden="true"></i>

                                <a href="contacts">Contact Us</a>

                            </li>

                            <li>

                                <i class="fa fa-caret-right" aria-hidden="true"></i>

                                <a href="about-us">About Us</a>

                            </li>

                            <li>

                                <i class="fa fa-caret-right" aria-hidden="true"></i>

                                <a href="terms">Terms & Condition</a>

                            </li>

							<li>

                                <i class="fa fa-caret-right" aria-hidden="true"></i>

                                <a href="https://ordersell.com/">OrderSell Home Page</a>

                            </li>

							

							<li>

                                <i class="fa fa-caret-right" aria-hidden="true"></i>

                                <a href="https://ordersell.com/int">OrderSell International Page</a>

                            </li>

                        </ul>

                    </div>

                </div>

            </div>



        </div>



        <div class="row">

            <div class="contacts">

                <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">

                    <div class="contacts-item">

                        <div class="icon js-animate-icon">

                            <svg enable-background="new 0 0 64 64" version="1.1" viewBox="0 0 64 64" xml:space="preserve" xmlns="http://www.w3.org/2000/svg"><path d="  M45.1,44.2C42.9,42,39.6,40,37,42.6c-1.8,1.8-2.6,3.9-2.6,3.9s-4.3,2.3-11.7-5.2s-5.2-11.7-5.2-11.7s2.1-0.8,3.9-2.6  c2.6-2.6,0.6-5.9-1.7-8.1c-2.7-2.7-6.2-4.9-8.2-2.9c-3.7,3.7-4.4,8.4-4.4,8.4S9,35.5,18.7,45.3s20.9,11.6,20.9,11.6s4.7-0.7,8.4-4.4  C50,50.4,47.8,46.9,45.1,44.2z" fill="none" stroke="#fcb03b" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"/><path d="  M18.4,12.2C22.2,9.5,26.9,8,32,8c13.3,0,24,10.8,24,24c0,4-1.3,9-4.4,12.2" fill="none" stroke="#fcb03b" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"/><path d="  M27.3,55.6c-9.8-1.9-17.5-9.8-19.1-19.7" fill="none" stroke="#fcb03b" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"/><path d="  M30,21c0,0,4.4,0,5.2,0c1.2,0,1.8,0.2,1.8,1.1s0,0.7,0,1.3c0,0.6,0,1.4-1.6,2.5c-2.3,1.6-5.6,3.8-5.6,5.1c0,1.6,0.7,2,1.8,2  s5.3,0,5.3,0" fill="none" stroke="#fcb03b" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"/><path d="  M40,21c0,0,0,2.8,0,3.8S39.9,27,41.5,27c1.6,0,4.5,0,4.5,0v-6.1V33" fill="none" stroke="#fcb03b" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"/></svg>

                        </div>

                        <div class="content">

                            <a href="" class="title">91 7900 916 000</a>

                            <p class="sub-title">Mon-Sun 10am-8pm</p>

                        </div>

                    </div>

                </div>



                <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">

                    <div class="contacts-item">

                        <div class="icon js-animate-icon">

                            <svg enable-background="new 0 0 64 64" version="1.1" viewBox="0 0 64 64" xml:space="preserve" xmlns="http://www.w3.org/2000/svg"><polyline fill="none" points="  54,17 32,36 10,17 " stroke="#f15b26" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"/><line fill="none" stroke="#f15b26" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2" x1="10.9" x2="26" y1="48" y2="36"/><path d="  M32.7,49H13c-2.2,0-4-1.8-4-4V19c0-2.2,1.8-4,4-4h38c2.2,0,4,1.8,4,4v15.5" fill="none" stroke="#f15b26" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"/><circle cx="44.9" cy="43.1" fill="none" r="10.1" stroke="#f15b26" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"/><path d="  M44,41.4c0,0-1.3,3.4-0.9,5.1c0.4,1.7,2.6,2.1,3.7,1.1" fill="none" stroke="#f15b26" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"/><g><circle cx="45.4" cy="38.3" fill="#DCE9EE" r="0.9"/><path d="M45.4,37.3c-0.5,0-0.9,0.4-0.9,0.9c0,0.5,0.4,0.9,0.9,0.9s0.9-0.4,0.9-0.9C46.4,37.8,46,37.3,45.4,37.3   L45.4,37.3z" fill="#f15b26"/></g></svg>

                        </div>

                        <div class="content">

                            <a href="mailto:info@ordersell.com" class="title">info@ordersell.com</a>

                            <p class="sub-title">online support</p>

                        </div>

                    </div>

                </div>



                <div class="col-lg-4 col-md-12 col-sm-12 col-xs-12">

                    <div class="contacts-item">

                        <div class="icon js-animate-icon">

                            <svg enable-background="new 0 0 64 64" version="1.1" viewBox="0 0 64 64" xml:space="preserve" xmlns="http://www.w3.org/2000/svg"><polygon fill="none" points="  38.7,36.4 56,32 38.7,27.6 42,22 36.4,25.3 32,8 27.6,25.3 22,22 25.3,27.6 8,32 25.3,36.4 22,42 27.6,38.7 32,56 36.4,38.7 42,42   " stroke="#3cb878" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"></polygon><circle cx="32" cy="32" fill="none" r="4" stroke="#3cb878" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"></circle><path d="  M26.1,53.2c-7.9-2.2-13.9-8.6-15.6-16.7" fill="none" stroke="#3cb878" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"></path><path d="  M53.5,36.9c-1.8,8.1-8.2,14.6-16.3,16.5" fill="none" stroke="#3cb878" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"></path><path d="  M36.9,10.5c8.2,1.9,14.7,8.3,16.6,16.6" fill="none" stroke="#3cb878" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"></path><path d="  M10.5,27.1c1.9-8.2,8.3-14.6,16.4-16.5" fill="none" stroke="#3cb878" stroke-linecap="round" stroke-linejoin="round" stroke-miterlimit="10" stroke-width="2"></path></svg>

                        </div>

                        <div class="content">

                            <a href="#" class="title">Navi Mumbai, India</a>

                            <p class="sub-title">Navi Mumbai</p>

                        </div>

                    </div>

                </div>

            </div>

        </div>



    </div>



    <div class="sub-footer">

        <div class="container">

            <div class="row">

                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

                    <span>

                        Copyright © 2023 <a href="https://ordersell.com" class="sub-footer__link">OrderSell.com</a>

                       

                    </span>



                  

                    



                    <a class="back-to-top" href="#">

                        <svg class="back-to-top">

                            <use xlink:href="#to-top"></use>

                        </svg>

                    </a>

                </div>

            </div>

        </div>

    </div>



 



<!-- End Footer -->



<svg style="display:none;">

    <symbol id="arrow-left" viewBox="122.9 388.2 184.3 85">

        <path d="M124.1,431.3c0.1,2,1,3.8,2.4,5.2c0,0,0.1,0.1,0.1,0.1l34.1,34.1c1.6,1.6,3.7,2.5,5.9,2.5s4.3-0.9,5.9-2.4

		c1.6-1.6,2.4-3.7,2.4-5.9s-0.9-3.9-2.4-5.5l-19.9-19.5h11.1c1.5,0,2.7-1.5,2.7-3c0-1.5-1.2-3-2.7-3h-17.6c-1.1,0-2.1,0.6-2.5,1.6

		c-0.4,1-0.2,2.1,0.6,2.9l24.4,24.4c0.6,0.6,0.9,1.3,0.9,2.1s-0.3,1.6-0.9,2.1c-0.6,0.6-1.3,0.9-2.1,0.9s-1.6-0.3-2.1-0.9

		l-34.2-34.2c0,0,0,0,0,0c-0.6-0.6-0.8-1.4-0.9-1.9c0,0,0,0,0,0c0-0.2,0-0.4,0-0.6c0.1-0.6,0.3-1.1,0.7-1.6c0-0.1,0.1-0.1,0.2-0.2

		l34.1-34.1c0.6-0.6,1.3-0.9,2.1-0.9s1.6,0.3,2.1,0.9c0.6,0.6,0.9,1.3,0.9,2.1s-0.3,1.6-0.9,2.1l-24.4,24.4c-0.8,0.8-1,2-0.6,3

		c0.4,1,1.4,1.7,2.5,1.7h125.7c1.5,0,2.7-1,2.7-2.5c0-1.5-1.2-2.5-2.7-2.5H152.6l19.9-20.1c1.6-1.6,2.4-3.8,2.4-6s-0.9-4.4-2.4-6

		c-1.6-1.6-3.7-2.5-5.9-2.5s-4.3,0.9-5.9,2.4l-34.1,34.1c-0.2,0.2-0.3,0.3-0.5,0.5c-1.1,1.2-1.8,2.8-2,4.4

		C124.1,430.2,124.1,430.8,124.1,431.3C124.1,431.3,124.1,431.3,124.1,431.3z"></path>

        <path d="M283.3,427.9h14.2c1.7,0,3,1.3,3,3c0,1.7-1.4,3-3,3H175.1c-1.5,0-2.7,1.5-2.7,3c0,1.5,1.2,3,2.7,3h122.4

		c4.6,0,8.4-3.9,8.4-8.5c0-4.6-3.8-8.5-8.4-8.5h-14.2c-1.5,0-2.7,1-2.7,2.5C280.7,426.9,281.8,427.9,283.3,427.9z"></path>

    </symbol>

    <symbol id="arrow-right" viewBox="122.9 388.2 184.3 85">

        <path d="M305.9,430.2c-0.1-2-1-3.8-2.4-5.2c0,0-0.1-0.1-0.1-0.1l-34.1-34.1c-1.6-1.6-3.7-2.5-5.9-2.5c-2.2,0-4.3,0.9-5.9,2.4

		c-1.6,1.6-2.4,3.7-2.4,5.9s0.9,4.1,2.4,5.7l19.9,19.6h-11.1c-1.5,0-2.7,1.5-2.7,3c0,1.5,1.2,3,2.7,3h17.6c1.1,0,2.1-0.7,2.5-1.7

		c0.4-1,0.2-2.2-0.6-2.9l-24.4-24.5c-0.6-0.6-0.9-1.3-0.9-2.1s0.3-1.6,0.9-2.1c0.6-0.6,1.3-0.9,2.1-0.9c0.8,0,1.6,0.3,2.1,0.9

		l34.2,34.2c0,0,0,0,0,0c0.6,0.6,0.8,1.4,0.9,1.9c0,0,0,0,0,0c0,0.2,0,0.4,0,0.6c-0.1,0.6-0.3,1.1-0.7,1.6c0,0.1-0.1,0.1-0.2,0.2

		l-34.1,34.1c-0.6,0.6-1.3,0.9-2.1,0.9s-1.6-0.3-2.1-0.9c-0.6-0.6-0.9-1.3-0.9-2.1s0.3-1.6,0.9-2.1l24.4-24.4c0.8-0.8,1-1.9,0.6-2.9

		c-0.4-1-1.4-1.6-2.5-1.6H158.1c-1.5,0-2.7,1-2.7,2.5c0,1.5,1.2,2.5,2.7,2.5h119.3l-19.9,20c-1.6,1.6-2.4,3.7-2.4,6s0.9,4.4,2.4,5.9

		c1.6,1.6,3.7,2.5,5.9,2.5s4.3-0.9,5.9-2.4l34.1-34.1c0.2-0.2,0.3-0.3,0.5-0.5c1.1-1.2,1.8-2.8,2-4.4

		C305.9,431.3,305.9,430.8,305.9,430.2C305.9,430.2,305.9,430.2,305.9,430.2z"></path>

        <path d="M146.7,433.9h-14.2c-1.7,0-3-1.3-3-3c0-1.7,1.4-3,3-3h122.4c1.5,0,2.7-1.5,2.7-3c0-1.5-1.2-3-2.7-3H132.4

		c-4.6,0-8.4,3.9-8.4,8.5c0,4.6,3.8,8.5,8.4,8.5h14.2c1.5,0,2.7-1,2.7-2.5C149.3,434.9,148.1,433.9,146.7,433.9z"></path>

    </symbol>

    <symbol id="to-top" viewBox="0 0 32 32">

        <path d="M17,22 L25.0005601,22 C27.7616745,22 30,19.7558048 30,17 C30,14.9035809 28.7132907,13.1085075 26.8828633,12.3655101

         L26.8828633,12.3655101 C26.3600217,9.87224935 24.1486546,8 21.5,8 C20.6371017,8 19.8206159,8.19871575 19.0938083,8.55288165

         C17.8911816,6.43144875 15.6127573,5 13,5 C9.13400656,5 6,8.13400656 6,12 C6,12.1381509 6.00400207,12.275367 6.01189661,12.4115388

          L6.01189661,12.4115388 C4.23965876,13.1816085 3,14.9491311 3,17 C3,19.7614237 5.23249418,22 7.99943992,22 L16,22 L16,16 L12.75,19.25

           L12,18.5 L16.5,14 L21,18.5 L20.25,19.25 L17,16 L17,22 L17,22 Z M16,22 L16,27 L17,27 L17,22 L16,22 L16,22 Z" id="cloud-upload"></path>

    </symbol>



</svg>



<!-- Overlay Search -->



 



<!-- End Overlay Search -->



<!-- JS Script -->



<script src="js/jquery-2.1.4.min.js"></script>

<script src="js/crum-mega-menu.js"></script>

<script src="js/swiper.jquery.min.js"></script>

<script src="js/theme-plugins.js"></script>

<script src="js/main.js"></script>

<script src="js/form-actions.js"></script>



<script src="js/velocity.min.js"></script>

<script src="js/ScrollMagic.min.js"></script>

<script src="js/animation.velocity.min.js"></script>





<!-- ...end JS Script -->



 

<!-- Google tag (gtag.js) -->

<script async src="https://www.googletagmanager.com/gtag/js?id=G-QBSHZ6VPBV"></script>

<script>

  window.dataLayer = window.dataLayer || [];

  function gtag(){dataLayer.push(arguments);}

  gtag('js', new Date());



  gtag('config', 'G-QBSHZ6VPBV');

</script>

 

</body>





</html>

