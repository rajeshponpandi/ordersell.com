<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $captcha = $_POST['g-recaptcha-response'];

    // Basic validation to ensure fields are not empty
    if (empty($name) || empty($phone) || empty($email) || empty($captcha)) {
        die('All fields are required.');
    }

    // Verify CAPTCHA
    $secret = '6LfbOAAqAAAAAORJDrrzW2zd3eGn6sQBjTznIf-k';
    $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secret&response=$captcha");
    $responseKeys = json_decode($response, true);

    if (intval($responseKeys['success']) !== 1) {
        die('CAPTCHA verification failed.');
    }

    // Email content
    $to = 'info@ordersell.com';
    $subject = 'Contact Form Submission';
    $message = "Name: $name\nPhone: $phone\nEmail: $email";
    $headers = "From: $email";

    // Send email
    if (mail($to, $subject, $message, $headers)) {
        echo 'Your message has been sent successfully.';
    } else {
        echo 'There was a problem sending your message. Please try again later.';
    }
} else {
    echo 'Invalid request.';
}
?>