<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website Packages</title>
    <style>
        .menu {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .menu button {
            margin: 0 10px;
            padding: 10px 20px;
            background-color: #b3b3b3;
            color: white;
            border: none;
            cursor: pointer;
            border-radius: 5px;
        }

        .menu button.active {
            background-color: #0056b3;
        }

        .plans-section {
            display: none;
        }

        .plans-section.active {
            display: block;
        }
    </style>
	
		  <!--Geo Targeting-->
<script>
        (function() {
            var xhr = new XMLHttpRequest();
            xhr.open('GET', 'https://ipapi.co/json/', false); // Synchronous request
            xhr.send(null);

            if (xhr.status === 200) {
                var geoData = JSON.parse(xhr.responseText);
                if (geoData.country_code !== 'IN') {
                    window.location.href = 'https://ordersell.com/web-hosting-int';
                }
            }
        })();
    </script>
 <!--Geo Targeting-->

	  <link rel="icon" type="image/x-icon" href="img/favicon.ico">



    <link rel="stylesheet" type="text/css" href="css/fonts.css">

    <link rel="stylesheet" type="text/css" href="css/crumina-fonts.css">

    <link rel="stylesheet" type="text/css" href="css/normalize.css">

    <link rel="stylesheet" type="text/css" href="css/grid.css">

    <link rel="stylesheet" type="text/css" href="css/base.css">

    <link rel="stylesheet" type="text/css" href="css/blocks.css">

    <link rel="stylesheet" type="text/css" href="css/layouts.css">

    <link rel="stylesheet" type="text/css" href="css/modules.css">

    <link rel="stylesheet" type="text/css" href="css/widgets-styles.css">





    <!--Plugins styles-->



    <link rel="stylesheet" type="text/css" href="css/jquery.mCustomScrollbar.min.css">

    <link rel="stylesheet" type="text/css" href="css/swiper.min.css">

    <link rel="stylesheet" type="text/css" href="css/primary-menu.css">

    <link rel="stylesheet" type="text/css" href="css/magnific-popup.css">



    <!--Styles for RTL-->


  <style>
    /* Keyframes for the blink effect */
    @keyframes blink {
      0% { opacity: 1; }
      50% { opacity: 0; }
      100% { opacity: 1; }
    }

    /* Applying the animation to the link */
    .blinking-link {
      animation: blink 1s infinite; /* Slowed down to 3 seconds */
      color: blue;
      text-decoration: none;
    }	
  </style>


    <!--<link rel="stylesheet" type="text/css" href="css/rtl.css">-->


    <!--External fonts-->



    <link href='https://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>

	

	 <script type="text/javascript">

        function toggle_visibility(tbid,lnkid)

        {

          var obj = document.getElementsByTagName("table");

          for(i=0;i<obj.length;i++)

          {

           if(obj[i].id && obj[i].id != tbid)

           {

            document.getElementById(obj[i].id).style.display = "none";

            x = obj[i].id.substring(3);

            document.getElementById("lnk"+x).value = "[+] Expand";

            }

           }

          if(document.all){document.getElementById(tbid).style.display = document.getElementById(tbid).style.display == "block" ? "none" : "block";}

          else{document.getElementById(tbid).style.display = document.getElementById(tbid).style.display == "table" ? "none" : "table";}

          document.getElementById(lnkid).value = document.getElementById(lnkid).value == "[-] Collapse" ? "[+] Expand" : "[-] Collapse";

         }

            </script>

            <style type="text/css">

            #tbl1,#tbl1 {display:none; text-transform: uppercase;}

            #tbl2,#tbl2 {display:none; text-transform: uppercase;}

            #tbl3,#tbl3 {display:none; text-transform: uppercase;}

            #tbl4,#tbl4 {display:none; text-transform: uppercase;}

            td {FONT-SIZE: 75%; MARGIN: 0px; COLOR: #000000;}

            td {FONT-FAMILY: verdana,helvetica,arial,sans-serif}

            a {TEXT-DECORATION: none;}

                </style>



<!-- Font Awesome -->

    <link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">

    

    <!-- Accordion CSS -->

    <link rel="stylesheet" href="css/style.css">

    

    <!--Only for demo purpose - no need to add.-->

    <link rel="stylesheet" type="text/css" href="demo.css" />

	<style type="text/css">

<!--
.style12 {color: #FF6600}
.style1 {color: #FF0000}
.style2 {
	font-size: 18px;
	color: #FF0000;
}

-->

    </style>

<!-- Google tag (gtag.js) event - delayed navigation helper -->
<script>
  // Helper function to delay opening a URL until a gtag event is sent.
  // Call it in response to an action that should navigate to a URL.
  function gtagSendEvent(url) {
    var callback = function () {
      if (typeof url === 'string') {
        window.location = url;
      }
    };
    gtag('event', 'conversion_event_purchase', {
      'event_callback': callback,
      'event_timeout': 2000,
      // <event_parameters>
    });
    return false;
  }
</script>


<style>
    /* WhatsApp Icon Styles */
    #whatsapp-icon {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 1000;
      width: 60px;
      height: 60px;
      background-color: #25d366;
      border-radius: 50%;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      transition: transform 0.3s ease-in-out;
    }

    #whatsapp-icon:hover {
      transform: scale(1.1);
    }

    #whatsapp-icon img {
      width: 40px;
      height: 40px;
      object-fit: cover;
    }
  </style>
  <style>
    /* Keyframes for the blink effect */
    @keyframes blink {
      0% { opacity: 1; }
      50% { opacity: 0; }
      100% { opacity: 1; }
    }

    /* Applying the animation to the link */
    .blinking-link {
      animation: blink 1s infinite; /* Slowed down to 3 seconds */
      color: blue;
      text-decoration: none;
    }	
  </style>  

</head>
<body>
 <div class="heading align-center">
                <h4 class="h1 heading-title">Complete Website Packages</h4>
                <div class="heading-line"> <span class="short-line"></span> <span class="long-line"></span> </div>
                <p class="heading-text">Below are the Website Service packages. </p>
              </div>
<div class="menu">
    <button id="hosting-btn" class="active">Hosting with Domain</button>
    <button id="hosting-domain-btn">Only Hosting</button>
</div>

<div id="hosting-plans" class="plans-section active">
    <!-- Hosting Plans Content (your provided hosting plans go here) -->
    <!-- Include your current plans HTML -->
    <div class="container-fluid">
      

     <div class="row">

        <div class="pricing-tables pricing-tables-head medium-bg-white-color">

            <div class="container">
            
              <div class="col-lg-24 col-md-4 col-sm-4 col-xs-12 no-padding">



                            <div class="pricing-tables-item">



                                <div class="pricing-head bg-primary-color"></div>



                                <div class="pricing-content-wrap">



                                    <div class="pricing-tables-icon">

                                      <img src="img/silver.png" alt="personal" width="93" height="93">                                </div>

                                <a href="#" target="_top" class="pricing-title"><span class="style1">Silver</span> </a>

                                <ul class="pricing-tables-position">

                                  

									 <li class="position-item">

                                        <span class="count">1</span>

                                        Website                                    </li>

                                    <li class="position-item">

                                        <span class="count">10 GB</span>

                                        Space                                    </li>

                                    <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Emails

                                    ID</li>

									

									

									<li class="position-item">

                                       <span class="count">Unlimited</span>

                                        Database</li>
                                    <li class="position-item">Free SSL                                     </li>
									<li class="position-item">

                                       <span class="count"> </span>  1 <span class="style3">Free</span> Domain (.com, .in, .us. .uk) Worth 1000 RS </li>
                                    <li class="position-item">

                                        <span class="count"> </span></li>

									
									</li>
                                </ul>

                                

								
								<h4 class="rate"><span class="style1"><strong>1200 Rs /Yr</strong></span></h4>
								
								<a href="https://ordersell.com/account/order.php?step=2&product=562&paymentTerm=12&paymentterm=12&currency=INR" class="btn btn-medium btn--dark">

                                    <span class="text">Buy Now!</span>

                                        <span class="semicircle"></span>

                                  </a>



                                </div>



                            </div>



              </div>



                        <div class="col-lg-24 col-md-4 col-sm-4 col-xs-12 no-padding">

                            <div class="pricing-tables-item">



                                <div class="pricing-head bg-secondary-color"></div>



                                <div class="pricing-content-wrap">



                                    <div class="pricing-tables-icon">

                                       <img src="img/gold.png" alt="personal">

                                </div>

                                <a href="#" class="pricing-title">Gold</a>

                                  <ul class="pricing-tables-position">

                                    

									<li class="position-item">

                                        <span class="count">3</span>

                                        Websites                                    </li>

                                    <li class="position-item"><strong>25</strong><span class="count"> GB</span>

                                        Space                                    </li>

                                    <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Email ID                                   </li>

									<li class="position-item">

                                        <span class="count">Unlimited</span>

                                    Database                                    
									<li class="position-item">Free SSL  </li>
									<li class="position-item">

                                       <span class="count"> </span>  1 <span class="style3">Free</span> Domain (.com, .in, .us. .uk) Worth 1000 RS </li>
                                    <li class="position-item">

                                        <span class="count"> </span></li>

									  

                                    <li class="position-item"></li>
                                  </ul>

                                

								
								<h4 class="rate">1500 Rs / Yr </h4>
								
								<a href="https://ordersell.com/account/order.php?step=2&product=561&paymentTerm=12&paymentterm=12&currency=INR" class="btn btn-medium btn--dark">

                                    <span class="text">Buy Now!</span>

                                        <span class="semicircle"></span>

                                  </a>



                                </div>

                            </div>

                        </div>

<div class="col-lg-24 col-md-4 col-sm-4 col-xs-12 no-padding">



                            <div class="pricing-tables-item">



                                <div class="pricing-head bg-orange-color"></div>



                                <div class="pricing-content-wrap">



                                    <div class="pricing-tables-icon">

                                      <img src="img/diamond.png" alt="personal">

                                </div>

                                <a href="#" class="pricing-title">Platinum</a>

                                  <ul class="pricing-tables-position">

                                    

									 <li class="position-item">

                                        <span class="count">5</span>

                                        Websites                                    </li>

                                     <li class="position-item">

                                        <span class="count">50 GB</span>

                                        Space                                    </li>

                                     <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Email ID                                    </li>

									<li class="position-item">

                                        <span class="count">Unlimited</span>

                                    Database                </li>                      
									<li class="position-item">Free SSL 
                                    

									</li><li class="position-item">

                                       <span class="count"> </span>  1 <span class="style3">Free</span> Domain (.com, .in, .us. .uk) Worth 1000 RS </li>
                                </ul>


								
								<h4 class="rate">2000 Rs / Yr </h4>
								
								<a href="https://ordersell.com/account/order.php?step=2&product=560&paymentTerm=12&paymentterm=12&currency=INR" class="btn btn-medium btn--dark">

                                    <span class="text">Buy Now!</span>

                                        <span class="semicircle"></span>

                                  </a>



                                </div>

                            </div>

                        </div>

                        <div class="col-lg-24 col-md-4 col-sm-4 col-xs-12 no-padding">



                            <div class="pricing-tables-item">



                                <div class="pricing-head bg-white-color"></div>



                                <div class="pricing-content-wrap">



                                    <div class="pricing-tables-icon">

                                      <img src="img/diamond.png" alt="personal">

                                </div>

                                <a href="#" class="pricing-title">Diamond</a>

                                  <ul class="pricing-tables-position">

                                    

									 <li class="position-item">

                                        <span class="count">10</span>

                                        Websites                                    </li>

                                     <li class="position-item">

                                        <span class="count">100 GB</span>

                                        Space                                    </li>

                                     <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Email ID                                    </li>

									<li class="position-item">

                                        <span class="count">Unlimited</span>

                                    Database     </li>                                
									<li class="position-item">Free SSL 
                                    

									</li>
									<li class="position-item">

                                       <span class="count"> </span>  1 <span class="style3">Free</span> Domain (.com, .in, .us. .uk) Worth 1000 RS </li>
                                </ul>


								
								<h4 class="rate">2500 Rs / Yr </h4>
								
								<a href="https://ordersell.com/account/order.php?step=2&product=559&paymentTerm=12&paymentterm=12&currency=INR" class="btn btn-medium btn--dark">

                                    <span class="text">Buy Now!</span>

                                        <span class="semicircle"></span>

                                  </a>



                                </div>

                            </div>

                        </div>



          </div>

      </div>

    </div>

  </div>

</div>

<div id="hosting-domain-plans" class="plans-section">
    <!-- Hosting with Domain Plans Content -->
    <div class="container-fluid">
      <div class="row">

        <div class="pricing-tables pricing-tables-head medium- bg-white-color">

            <div class="container">
             
               <div class="col-lg-24 col-md-24 col-sm-24 col-xs-24 no-padding">



                            <div class="pricing-tables-item">



                                <div class="pricing-head bg-primary-color"></div>



                                <div class="pricing-content-wrap">



                                    <div class="pricing-tables-icon">

                                      <img src="img/silver.png" alt="personal" width="93" height="93">                                </div>

                                <a href="#" target="_top" class="pricing-title"><span class="style1">Silver</span> </a>

                                <ul class="pricing-tables-position">

                                  

									 <li class="position-item">

                                        <span class="count">1</span>

                                        Website                                    </li>

                                    <li class="position-item">

                                        <span class="count">10 GB</span>

                                        Space                                    </li>

                                    <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Emails

                                    ID</li>

									

									

									<li class="position-item">

                                       <span class="count">Unlimited</span>

                                        Database</li>
                                    <li class="position-item">Free SSL                                     </li>
                                  <li class="position-item">

                                        <span class="count"> </span></li>

									
									</li>
                                </ul>

                                

								
								<h4 class="rate"><span class="style1"><strong>250 Rs /Yr</strong></span></h4>
								
								<a href="https://ordersell.com/account/order.php?step=2&product=1&paymentterm=12&currency=INR" class="btn btn-medium btn--dark">

                                    <span class="text">Buy Now!</span>

                                        <span class="semicircle"></span>

                                  </a>



                                </div>



                            </div>



              </div>



                         <div class="col-lg-24 col-md-24 col-sm-24 col-xs-24 no-padding">

                            <div class="pricing-tables-item">



                                <div class="pricing-head bg-secondary-color"></div>



                                <div class="pricing-content-wrap">



                                    <div class="pricing-tables-icon">

                                       <img src="img/gold.png" alt="personal">

                                </div>

                                <a href="#" class="pricing-title">Gold</a>

                                  <ul class="pricing-tables-position">

                                    

									<li class="position-item">

                                        <span class="count">3</span>

                                        Websites                                    </li>

                                    <li class="position-item"><strong>25</strong><span class="count"> GB</span>

                                        Space                                    </li>

                                    <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Email ID                                   </li>

									<li class="position-item">

                                        <span class="count">Unlimited</span>

                                    Database                                    
									<li class="position-item">Free SSL 
                                    <li class="position-item">

                                        <span class="count"> </span></li>

									  

                                    <li class="position-item"></li>
                                  </ul>

                                

								
								<h4 class="rate">500 Rs / Yr </h4>
								
								<a href="https://ordersell.com/account/order.php?step=2&product=2&paymentTerm=12&currency=INR" class="btn btn-medium btn--dark">

                                    <span class="text">Buy Now!</span>

                                        <span class="semicircle"></span>

                                  </a>



                                </div>

                            </div>

                        </div>

 <div class="col-lg-24 col-md-24 col-sm-24 col-xs-24 no-padding">



                            <div class="pricing-tables-item">



                                <div class="pricing-head bg-orange-color"></div>



                                <div class="pricing-content-wrap">



                                    <div class="pricing-tables-icon">

                                      <img src="img/platinum.png" alt="personal">

                                </div>

                                <a href="#" class="pricing-title">Platinum</a>

                                  <ul class="pricing-tables-position">

                                    

									 <li class="position-item">

                                        <span class="count">5</span>

                                        Websites                                    </li>

                                     <li class="position-item">

                                        <span class="count">50 GB</span>

                                        Space                                    </li>

                                     <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Email ID                                    </li>

									<li class="position-item">

                                        <span class="count">Unlimited</span>

                                    Database                                    
									<li class="position-item">Free SSL 
                                    

                                   

									</li>
                                </ul>


								
								<h4 class="rate">1000 Rs / Yr </h4>
								
								<a href="https://ordersell.com/account/order.php?step=2&product=563&paymentTerm=12&paymentterm=12&currency=INR" class="btn btn-medium btn--dark">

                                    <span class="text">Buy Now!</span>

                                        <span class="semicircle"></span>

                                  </a>



                                </div>

                            </div>

                        </div>

                         <div class="col-lg-24 col-md-24 col-sm-24 col-xs-24 no-padding">



                            <div class="pricing-tables-item">



                                <div class="pricing-head bg-white-color"></div>



                                <div class="pricing-content-wrap">



                                    <div class="pricing-tables-icon">

                                      <img src="img/diamond.png" alt="personal">

                                </div>

                                <a href="#" class="pricing-title">Diamond</a>

                                  <ul class="pricing-tables-position">

                                    

									 <li class="position-item">

                                        <span class="count">10</span>

                                        Websites                                    </li>

                                     <li class="position-item">

                                        <span class="count">100 GB</span>

                                        Space                                    </li>

                                     <li class="position-item">

                                        <span class="count">Unlimited</span>

                                        Email ID                                    </li>

									<li class="position-item">

                                        <span class="count">Unlimited</span>

                                    Database                                    
									<li class="position-item">Free SSL 
                                    

                                   

									</li>
                                </ul>


								
								<h4 class="rate">1500 Rs / Yr </h4>
								
								<a href="https://ordersell.com/account/order.php?step=2&product=3&paymentTerm=12&currency=INR" class="btn btn-medium btn--dark">

                                    <span class="text">Buy Now!</span>

                                        <span class="semicircle"></span>

                                  </a>



                                </div>

                            </div>

                        </div>



          </div>

      </div>

    </div>

  </div>

</div>
    </div>
</div>


<script>
    document.getElementById('hosting-btn').addEventListener('click', function() {
        document.getElementById('hosting-plans').classList.add('active');
        document.getElementById('hosting-domain-plans').classList.remove('active');
        this.classList.add('active');
        document.getElementById('hosting-domain-btn').classList.remove('active');
    });

    document.getElementById('hosting-domain-btn').addEventListener('click', function() {
        document.getElementById('hosting-domain-plans').classList.add('active');
        document.getElementById('hosting-plans').classList.remove('active');
        this.classList.add('active');
        document.getElementById('hosting-btn').classList.remove('active');
    });
</script>

</body>
</html>
