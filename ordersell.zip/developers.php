<?php
// Database configuration
$host = "localhost";
$username = "orde_creators";
$password = "Maha@25890";
$dbname = "orde_creators";

// Create a database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = $_POST['name'];
    $details = $_POST['details'];
    $email = $_POST['email'];

    // Handle logo upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["company_logo"]["name"]);
    move_uploaded_file($_FILES["company_logo"]["tmp_name"], $target_file);

    // Insert developer into database with `approved` set to FALSE
    $stmt = $conn->prepare("INSERT INTO developers (name, company_logo, details, email, approved) VALUES (?, ?, ?, ?, FALSE)");
    $stmt->bind_param("ssss", $name, $target_file, $details, $email);
    $stmt->execute();

    // Generate approval link
    $developer_id = $conn->insert_id;
    $approval_link = "http://ordersell.com/approve-creator.php?id=$developer_id";

    // Send email to admin
    $to = "info@ordersell.com";
    $subject = "New Developer Approval Required";
    $message = "A new developer has been submitted:\n\n" .
               "Name: $name\n" .
               "Details: $details\n\n" .
               "Click the link below to approve the developer:\n$approval_link";
    $headers = "From: no-reply@orgifsolutions.com";

    mail($to, $subject, $message, $headers);

    echo "Developer submitted for approval. Admin will review and approve.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Developer</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Add Developer</h1>
    <form method="POST" action="" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="name" class="form-label">Developer Name</label>
            <input type="text" class="form-control" id="name" name="name" required>
        </div>
        <div class="mb-3">
            <label for="details" class="form-label">Details</label>
            <textarea class="form-control" id="details" name="details" rows="4" required></textarea>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">Developer Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>
        <div class="mb-3">
            <label for="company_logo" class="form-label">Company Logo</label>
            <input type="file" class="form-control" id="company_logo" name="company_logo" accept="image/*" required>
        </div>
        <button type="submit" class="btn btn-primary">Submit Developer</button>
    </form>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>