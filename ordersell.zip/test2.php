<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];

    $to = "your-email@example.com";  // Replace with your email address
    $subject = "Contact Form Submission";
    $message = "Name: $name\nPhone: $phone\nEmail: $email";
    $headers = "From: $email";

    if (mail($to, $subject, $message, $headers)) {
        echo "Mail Sent!";
    } else {
        echo "Failed to send mail.";
    }
}
?>

<head>

<style>
    /* General Styles */
    body {
        font-family: Arial, sans-serif;
    }

    form {
        max-width: 600px;
        margin: 0 auto;
        padding: 20px;
        border: 1px solid #ccc;
        border-radius: 8px;
        background-color: #f9f9f9;
    }

    /* Form Row Style */
    .form-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 20px;
    }

    /* Form Group Style for Inputs */
    .form-group {
        flex: 1;
        display: flex;
        flex-direction: column;
        margin-right: 10px;
    }

    .form-group:last-child {
        margin-right: 0;
    }

    label {
        margin-bottom: 5px;
        font-weight: bold;
    }

    input[type="text"],
    input[type="email"] {
        padding: 8px;
        border: 1px solid #ccc;
        border-radius: 4px;
        box-sizing: border-box;
    }

    /* Captcha and Submit Group Style */
    .captcha-group {
        flex: 2;
        display: flex;
        align-items: center;
    }

    .submit-group {
        flex: 1;
        display: flex;
        align-items: center;
        justify-content: flex-end;
    }

    /* Submit Button Style */
    button {
        padding: 10px 15px;
        background-color: #4CAF50;
        color: white;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        width: 100%;
        font-size: 16px;
    }

    button:hover {
        background-color: #45a049;
    }
</style>
   <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#contactForm').on('submit', function(e) {
                e.preventDefault();
                var recaptcha = grecaptcha.getResponse();
                if (recaptcha === "") {
                    $('#message').removeClass('success').addClass('error').text('Please complete the CAPTCHA').show();
                    return false;
                }
                
                var formData = $(this).serialize();
                
                $.ajax({
                    type: 'POST',
                    url: '',
                    data: formData,
                    dataType: 'json',
                    success: function(response) {
                        $('#message').removeClass('error success');
                        if (response.success) {
                            $('#message').addClass('success').text(response.message).show();
                            $('#contactForm')[0].reset();
                            grecaptcha.reset();
                        } else {
                            $('#message').addClass('error').text(response.message).show();
                        }
                    },
                    error: function() {
                        $('#message').addClass('error').text('An error occurred. Please try again later.').show();
                    }
                });
            });
        });
    </script>

<style>
    /* WhatsApp Icon Styles */
    #whatsapp-icon {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 1000;
      width: 60px;
      height: 60px;
      background-color: #25d366;
      border-radius: 50%;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      transition: transform 0.3s ease-in-out;
    }

    #whatsapp-icon:hover {
      transform: scale(1.1);
    }

    #whatsapp-icon img {
      width: 40px;
      height: 40px;
      object-fit: cover;
    }
  </style>
  <style>
    /* Keyframes for the blink effect */
    @keyframes blink {
      0% { opacity: 1; }
      50% { opacity: 0; }
      100% { opacity: 1; }
    }

    /* Applying the animation to the link */
    .blinking-link {
      animation: blink 1s infinite; /* Slowed down to 3 seconds */
      color: blue;
      text-decoration: none;
    }	
  </style>  

</head>

<body>



<form id="contactForm" action="your-server-endpoint" method="POST">
    <!-- First Row: Name, Phone Number, Email -->
    <div class="form-row">
        <div class="form-group">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
        </div>
        <div class="form-group">
            <label for="phone">Phone Number:</label>
            <input type="text" id="phone" name="phone" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
        </div>
    </div>
    
    <!-- Second Row: reCAPTCHA and Submit Button -->
    <div class="form-row">
        <div class="captcha-group">
            <div class="g-recaptcha" data-sitekey="6LfbOAAqAAAAALCbVuKeIu6VX90R4E0Y3JnBDM1k"></div>
        </div>
        <div class="submit-group">
            <button type="submit">Submit</button>
        </div>
    </div>
</form>

</body>