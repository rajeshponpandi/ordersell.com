document.addEventListener('DOMContentLoaded', (event) => {
    const captchaValue = document.getElementById('captcha-value');
    const captchaText = generateCaptcha();
    captchaValue.textContent = captchaText;
});

function generateCaptcha() {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let captcha = '';
    for (let i = 0; i < 6; i++) {
        captcha += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return captcha;
}

function validateForm() {
    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;
    const email = document.getElementById('email').value;
    const captcha = document.getElementById('captcha').value;
    const captchaValue = document.getElementById('captcha-value').textContent;

    if (name === '' || phone === '' || email === '') {
        alert('All fields are required.');
        return false;
    }

    if (captcha !== captchaValue) {
        alert('Incorrect CAPTCHA.');
        return false;
    }

    return true;
}
