<?php include 'developers.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Developer Listings</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-5">
    <h1 class="text-center">Developer Listings</h1>
    <div class="row">
        <?php foreach ($developers as $developer): ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="<?php echo $developer['company_logo']; ?>" class="card-img-top" alt="Logo">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo $developer['name']; ?></h5>
                        <p class="card-text"><?php echo $developer['details']; ?></p>
                        <button class="btn btn-primary request-quote-btn" 
                                data-id="<?php echo $developer['id']; ?>"
                                data-bs-toggle="modal" 
                                data-bs-target="#quoteModal">
                            Request Quote
                        </button>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<!-- Modal for request quote -->
<div class="modal fade" id="quoteModal" tabindex="-1" aria-labelledby="quoteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="developers.php">
                <div class="modal-header">
                    <h5 class="modal-title" id="quoteModalLabel">Request Quote</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" id="developer_id" name="developer_id">
                    <div class="mb-3">
                        <label for="visitor_name" class="form-label">Your Name</label>
                        <input type="text" class="form-control" id="visitor_name" name="visitor_name" required>
                    </div>
                    <div class="mb-3">
                        <label for="visitor_phone" class="form-label">Your Phone</label>
                        <input type="text" class="form-control" id="visitor_phone" name="visitor_phone" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Send Request</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
<script>
    document.querySelectorAll('.request-quote-btn').forEach(button => {
        button.addEventListener('click', function () {
            document.getElementById('developer_id').value = this.getAttribute('data-id');
        });
    });
</script>
</body>
</html>
