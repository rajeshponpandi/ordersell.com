<?php
global $_POST;
$mail_to = 'info@ordersell.com'; //Your email here

// Required fields
$email = isset( $_POST['email'] ) ? strip_tags( trim( $_POST['email'] ) ) : '';
$name  = isset( $_POST['name'] ) ? strip_tags( trim( $_POST['name'] ) ) : '';
$text  = isset( $_POST['message'] ) ? strip_tags( trim( $_POST['message'] ) ) : '';
// Additional fields
$subject   = isset( $_POST['subject'] ) ? strip_tags( trim( $_POST['subject'] ) ) : '';
$permalink = isset( $_POST['permalink'] ) ? strip_tags( trim( $_POST['permalink'] ) ) : '';
$phone     = isset( $_POST['phone'] ) ? strip_tags( trim( $_POST['phone'] ) ) : '';
$company   = isset( $_POST['company'] ) ? strip_tags( trim( $_POST['company'] ) ) : '';


$mail_subject = $subject != '' ? $subject : 'From Contact form on website';

$message = 'You got a mail from OrderSell Contact Page:' . '';

$message .= 'Name: ' . $name . '';
$message .= 'Email: ' . $email . '';

if ( ! empty( $permalink ) ) {
	$message .= 'Website: ' . $permalink . '';
}
if ( ! empty( $phone ) ) {
	$message .= 'Phone: ' . $phone . '';
}
if ( ! empty( $company ) ) {
	$message .= 'Company: ' . $company . '';
}

$message .= 'Message: ' . $text . '';
$headers = 'MIME-Version: 1.0' . '\r\n';
$headers .= 'Content-type:text/html;charset=UTF-8' . '\r\n';

// More headers
$headers .= 'From: "'.$name.'"<' . $email . '>' . '\r\n';

mail( $mail_to, $mail_subject, $message, $headers );
