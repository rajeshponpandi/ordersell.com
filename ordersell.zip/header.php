<!DOCTYPE html>
<html lang="en">
<head lang="en">
         <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="keywords" content="domain, hosting, website hosting, domain and hosting, buy domain and hosting, ssl, vps, website design" />
<meta name="description" content="Buy domain & web hosting services from Ordersell.com to get your business online in simple steps. Host your domain on a plan that features 99.9% uptime and 24/7 tech support." />
    <meta name="google-site-verification" content="Y09viozL2gymynlQvRtsaMXmjEqK1tSJOccWMh8HYBY">
    <title>Buy Domains, Hosting, for Websites - OrderSell</title>
    <meta name="robots" content="index,follow">
   
    <link rel="icon" type="image/x-icon" href="img/favicon.ico">

    <link rel="stylesheet" type="text/css" href="css/fonts.css">
    <link rel="stylesheet" type="text/css" href="css/crumina-fonts.css">
    <link rel="stylesheet" type="text/css" href="css/normalize.css">
    <link rel="stylesheet" type="text/css" href="css/grid.css">
    <link rel="stylesheet" type="text/css" href="css/base.css">
    <link rel="stylesheet" type="text/css" href="css/blocks.css">
    <link rel="stylesheet" type="text/css" href="css/layouts.css">
    <link rel="stylesheet" type="text/css" href="css/modules.css">
    <link rel="stylesheet" type="text/css" href="css/widgets-styles.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
   


    <!--Plugins styles-->

    <link rel="stylesheet" type="text/css" href="css/jquery.mCustomScrollbar.min.css">
    <link rel="stylesheet" type="text/css" href="css/swiper.min.css">
    <link rel="stylesheet" type="text/css" href="css/primary-menu.css">
   

    <!--Styles for RTL-->

    <!--<link rel="stylesheet" type="text/css" href="css/rtl.css">-->

    <!--External fonts-->

    <link href='https://fonts.googleapis.com/css?family=Varela+Round' rel='stylesheet' type='text/css'>
    <style type="text/css">
<!--
.style1 {color: #FF0000}
.style2 {color: #FFFF00}
.style4 {color: #FF0000}
.style6 {color: #000000}
-->
    </style>
	
	
<style>
    /* WhatsApp Icon Styles */
    #whatsapp-icon {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 1000;
      width: 60px;
      height: 60px;
      background-color: #25d366;
      border-radius: 50%;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      transition: transform 0.3s ease-in-out;
    }

    #whatsapp-icon:hover {
      transform: scale(1.1);
    }

    #whatsapp-icon img {
      width: 40px;
      height: 40px;
      object-fit: cover;
    }
  </style>
  <style>
    /* Keyframes for the blink effect */
    @keyframes blink {
      0% { opacity: 1; }
      50% { opacity: 0; }
      100% { opacity: 1; }
    }

    /* Applying the animation to the link */
    .blinking-link {
      animation: blink 1s infinite; /* Slowed down to 3 seconds */
      color: blue;
      text-decoration: none;
    }	
  </style>  

</head>


<body class=" ">

<!-- Header -->
<div class="top-bar top-bar-dark">
    <div class="container">
            <div class="top-bar-contact">
                <div class="contact-item style9">
                <a href="https://ordersell.com"><strong>Home</strong></a>                </div>

                <div class="contact-item">
                    91 7900 916 000
                </div>

                <div class="contact-item">
                    <a href="mailto:info@ordersell.com">info@ordersell.com</a>
                </div>

                <div class="contact-item">
                    <span>Mon. - Sun.</span> 09:00 - 21:00 IST
                </div>
            </div>

            <div class="login-block">
                <img src="img/signin_dark.png" class="sign-in">
                <a href="https://ordersell.com/account/index.php?fuse=home&view=login">My Account</a> 
            </div>

             
  </div>

         


</div>
</div>


<!-- Header -->


<header class="header" id="site-header">

    <div class="container">

        <div class="header-content-wrapper">

            <div class="logo">
                <a href="https://ordersell.com" class="full-block-link"></a>
                <img src="img/logo.png" alt="Seosight">
                <div class="logo-text">                </div>
            </div>

            <nav id="primary-menu" class="primary-menu">

                <a href='javascript:void(0)' id="menu-icon-trigger" class="menu-icon-trigger showhide">
                    <span class="mob-menu--title">Menu</span>
                        <span id="menu-icon-wrapper" class="menu-icon-wrapper" style="visibility: hidden">
                            <svg width="1000px" height="1000px">
                                <path id="pathD" d="M 300 400 L 700 400 C 900 400 900 750 600 850 A 400 400 0 0 1 200 200 L 800 800"></path>
                                <path id="pathE" d="M 300 500 L 700 500"></path>
                                <path id="pathF" d="M 700 600 L 300 600 C 100 600 100 200 400 150 A 400 380 0 1 1 200 800 L 800 200"></path>
                            </svg>
                        </span>                </a>

                <!-- menu-icon-wrapper -->

                 <ul class="primary-menu-menu">
                      

                       <li>
            <a href="domain-registration">
                <span class="style1"></span>Domain          </a>
            <ul class="dropdown">
                
                <li>
                    <a href="https://ordersell.com/account/order.php?step=1&productGroup=2" target="_blank">Domain Register & Transfer <i class="seoicon-right-arrow"></i></a>                </li>
            </ul>
        </li>
			   <li>  <a href="web-hosting">Web Hosting</a>        </li>
        <li>
            <a href="vps-server">Servers</a>        </li>
         
		
		 <li>
            <a>
                 <span class="style1"></span>Development</a>
            <ul class="dropdown">
                <li>
                    <a href="website-development"> Website Development<i class="seoicon-right-arrow"></i></a>                </li>
                <li>
                    <a href="software-development">Software Development <i class="seoicon-right-arrow"></i></a>                </li>
            </ul>
        </li>
		
        <li>
            <a href="ssl-certificate">SSL</a>        </li>

<li>
            <a>
                <span class="style1"></span>Downloads</a>
            <ul class="dropdown">
                
                <li>
                    <a href="free-templates">Website Templates <i class="seoicon-right-arrow"></i></a>                </li>
            </ul>
</li>
</nav>

            <ul class="nav-add">
                 

                 
            </ul>

            
      </div>

    </div>




<div class="header-spacer"></div>

<!-- ... End Header -->

<!-- Right-menu -->



<!-- ... End Right-menu -->

<div class="content-wrapper">

<!-- Stunning header -->


      <marquee class="sampleMarquee" direction="left" scrollamount="15" behavior="scroll">Cheapest <span class="style2">.Com</span> Domain at <span class="style2">9 $</span> |  <span class="style2">Free</span> Web Hosting Services in India   |  <span class="style2">Free</span> Website Templates   |  <span class="style2">Cheapest</span> VPS Server
      </marquee>

<!-- End Stunning header -->

<!-- Overlay search -->

<div class="overlay_search">
    <div class="container">
        <div class="row">
          <div class="form_search-wrap">
                <form>
                    <input class="overlay_search-input" placeholder="Type and hit Enter..." type="text">
                    <a href="#" class="overlay_search-close">
                        <span></span>
                        <span></span>
                    </a>
                </form>
          </div>
        </div>
    </div>
</div>

</header>