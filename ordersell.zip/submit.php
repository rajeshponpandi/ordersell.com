<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $secretKey = "6LfbOAAqAAAAAORJDrrzW2zd3eGn6sQBjTznIf-k";
    $captcha = $_POST['g-recaptcha-response'];
    
    if (!$captcha) {
        echo json_encode(['success' => false, 'message' => 'Please check the CAPTCHA form.']);
        exit;
    }
    
    $ip = $_SERVER['REMOTE_ADDR'];
    $response = file_get_contents("https://www.google.com/recaptcha/api/siteverify?secret=$secretKey&response=$captcha&remoteip=$ip");
    $responseKeys = json_decode($response, true);
    
    if (intval($responseKeys["success"]) !== 1) {
        echo json_encode(['success' => false, 'message' => 'Please check the CAPTCHA form.']);
    } else {
        $name = htmlspecialchars($_POST['name']);
        $email = htmlspecialchars($_POST['email']);
        $phone = htmlspecialchars($_POST['phone']);
        $service = htmlspecialchars($_POST['service']);
        $message = htmlspecialchars($_POST['message']);
        
        $to = "info@ordersell.com";
        $subject = "Contact Form Submission from $name";
        $headers = "From: $email" . "\r\n" .
                   "Reply-To: $email" . "\r\n" .
                   "X-Mailer: PHP/" . phpversion();
        
        $body = "Name: $name\nEmail: $email\nPhone: $phone\nService Type: $service\n\nMessage:\n$message";
        
        if (mail($to, $subject, $body, $headers)) {
            echo json_encode(['success' => true, 'message' => 'Message sent successfully!']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to send message.']);
        }
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
}
?>




