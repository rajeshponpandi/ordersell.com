<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST["name"]);
    $phone = trim($_POST["phone"]);
    $email = trim($_POST["email"]);

    if (!empty($name) && !empty($phone) && !empty($email)) {
        $to = "info@ordersell.com";
        $subject = "New Contact Form Submission";
        $message = "Name: $name\nPhone: $phone\nEmail: $email";
        $headers = "From: noreply@ordersell.com";

        if (mail($to, $subject, $message, $headers)) {
            echo "Thank you for contacting us!";
        } else {
            echo "Error sending email.";
        }
    } else {
        echo "All fields are required.";
    }
} else {
    echo "Invalid request.";
}
?>