<?php
// Initialize a message variable to display feedback to the user
$message = "";

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize email input
    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);

    // Check if the email is valid
    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
        // Set up email details
        $to = "info@ordersell.com";  // The email address where unsubscribe requests will be sent
        $subject = "Unsubscribe Request";
        $body = "Please unsubscribe the following email address from the mailing list:\n\n$email";
        $headers = "From: no-reply@ordersell.com";  // Make sure to replace with a valid 'from' email address

        // Send the email
        if (mail($to, $subject, $body, $headers)) {
            $message = "<p>You have been successfully unsubscribed. We have received your request.</p>";
        } else {
            $message = "<p>Sorry, there was an error processing your request. Please try again later.</p>";
        }
    } else {
        $message = "<p>Please enter a valid email address.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Unsubscribe from Mailing List</title>
<style>
    /* WhatsApp Icon Styles */
    #whatsapp-icon {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 1000;
      width: 60px;
      height: 60px;
      background-color: #25d366;
      border-radius: 50%;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      transition: transform 0.3s ease-in-out;
    }

    #whatsapp-icon:hover {
      transform: scale(1.1);
    }

    #whatsapp-icon img {
      width: 40px;
      height: 40px;
      object-fit: cover;
    }
  </style>
  <style>
    /* Keyframes for the blink effect */
    @keyframes blink {
      0% { opacity: 1; }
      50% { opacity: 0; }
      100% { opacity: 1; }
    }

    /* Applying the animation to the link */
    .blinking-link {
      animation: blink 1s infinite; /* Slowed down to 3 seconds */
      color: blue;
      text-decoration: none;
    }	
  </style>  

</head>
<body>
    <h2>Unsubscribe from Our Mailing List</h2>
    <p>If you no longer wish to receive emails from us, please enter your email address below to unsubscribe.</p>

    <?php
    // Display message after form submission
    if (!empty($message)) {
        echo $message;
    }
    ?>

    <form action="unsubscribe.php" method="POST">
        <label for="email">Email Address:</label>
        <input type="email" id="email" name="email" required>
        <button type="submit">Unsubscribe</button>
    </form>
</body>
</html>
