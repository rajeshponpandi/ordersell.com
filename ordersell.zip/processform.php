<?php
session_start();
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $captcha = trim($_POST['captcha']);

    // Server-side validation
    if (empty($name) || empty($phone) || empty($email) || empty($captcha)) {
        $message = 'All fields are required.';
    } elseif ($captcha != $_SESSION['captcha_text']) {
        $message = 'CAPTCHA is incorrect. Please try again.';
    } else {
        $to = 'info@ordersell.com';
        $subject = 'HomePage CallBack Form India';
        $message_body = "Name: $name\nPhone: $phone\nEmail: $email";
        $headers = "From: $email";

        if (mail($to, $subject, $message_body, $headers)) {
            $message = 'Your message has been sent successfully.';
        } else {
            $message = 'There was a problem sending your message.';
        }
        // Clear CAPTCHA after successful form submission
        unset($_SESSION['captcha_text']);
    }
    $_SESSION['message'] = $message;
    header('Location: index.php');
    exit();
}
?>
