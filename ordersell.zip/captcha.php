<?php
session_start();

header('Content-type: image/png');

$captcha_code = '';
$characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
$length = 6;

for ($i = 0; $i < $length; $i++) {
    $captcha_code .= $characters[rand(0, strlen($characters) - 1)];
}

$_SESSION['captcha_code'] = $captcha_code;

$image = imagecreate(120, 40);
$background_color = imagecolorallocate($image, 255, 255, 255);
$text_color = imagecolorallocate($image, 0, 0, 0);
$font_size = 5;

imagestring($image, $font_size, 15, 10, $captcha_code, $text_color);

imagepng($image);
imagedestroy($image);
?>
