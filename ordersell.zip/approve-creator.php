<?php
// Database configuration
$host = "localhost";
$username = "orde_creators";
$password = "Maha@25890";
$dbname = "orde_creators";

// Create a database connection
$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get developer ID from the URL
if (isset($_GET['id'])) {
    $developer_id = intval($_GET['id']);

    // Approve the developer
    $stmt = $conn->prepare("UPDATE developers SET approved = TRUE WHERE id = ?");
    $stmt->bind_param("i", $developer_id);
    if ($stmt->execute()) {
        echo "Developer approved successfully!";
    } else {
        echo "Failed to approve developer.";
    }
} else {
    echo "Invalid request.";
}
?>